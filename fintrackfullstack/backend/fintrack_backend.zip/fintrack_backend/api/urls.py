from django.urls import path
from .views import (
    CategoryListCBV,
    TransactionDetailCBV,
    transaction_list_fbv,
    monthly_report_fbv,
    register,
    BudgetListCBV,
    BudgetDetailCBV,
    FinancialGoalListCBV,
    FinancialGoalDetailCBV,
    goal_deposit,
)
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    # Аутентификация
    path('register/', register),                                         # ИСПРАВЛЕНИЕ 4
    path('login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # Категории
    path('categories/', CategoryListCBV.as_view()),

    # Транзакции
    path('transactions/', transaction_list_fbv),
    path('transactions/<int:pk>/', TransactionDetailCBV.as_view()),

    # Отчёты
    path('report/', monthly_report_fbv),

    # Бюджеты (ИСПРАВЛЕНИЕ 3)
    path('budgets/', BudgetListCBV.as_view()),
    path('budgets/<int:pk>/', BudgetDetailCBV.as_view()),

    # Финансовые цели (ИСПРАВЛЕНИЕ 3)
    path('goals/', FinancialGoalListCBV.as_view()),
    path('goals/<int:pk>/', FinancialGoalDetailCBV.as_view()),
    path('goals/<int:pk>/deposit/', goal_deposit),  # новый
]